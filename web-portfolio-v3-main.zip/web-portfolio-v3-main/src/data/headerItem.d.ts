export interface HeaderItem {
  label: string;
  link: string;
}
