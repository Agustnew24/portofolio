export interface IEducation {
  name: string;
  type: string;
  major: string;
  timePeriod: string;
}
