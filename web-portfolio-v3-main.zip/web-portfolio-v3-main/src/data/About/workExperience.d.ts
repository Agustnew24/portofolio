export interface IWorkExperience {
  name: string;
  type: string;
  tasks: string[];
  timePeriod: string;
}
