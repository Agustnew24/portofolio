export const skillCategories = [
  'Language',
  'Framework/Library',
  'UI Framework/Component',
  'DBMS',
  'Operating System',
] as const;
