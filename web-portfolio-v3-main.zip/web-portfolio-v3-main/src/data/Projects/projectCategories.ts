export const projectCategories = [
  'Website',
  'Bot',
  'CLI',
  'API',
  'Misc',
] as const;
