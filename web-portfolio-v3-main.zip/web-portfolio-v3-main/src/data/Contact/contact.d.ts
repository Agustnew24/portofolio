export interface Contact {
  name: string;
  link: string;
  label: string;
}
