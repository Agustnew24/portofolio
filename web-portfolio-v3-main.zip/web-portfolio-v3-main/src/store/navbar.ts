import { atom } from 'jotai';

export const navbarAtom = atom(false);
